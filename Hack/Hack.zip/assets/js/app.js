let userName = document.getElementById('username')
let emailEl = document.getElementById('email')
let passwordEl = document.getElementById('password')
let errorMsg = document.getElementById('error')
let storage = firebase.storage();
let auth = firebase.auth();
var db = firebase.firestore();
const LoginForm = document.querySelector('.login-form')
let usernumber = document.getElementById('usernumber')
let usercountry = document.getElementById('usercountry')
let userRole = document.getElementById('user-role') 
console.log(userRole)
let card = document.getElementById('card')
console.log(card)
let cards = document.getElementById('cards')
let restaurantName = document.getElementById('restaurantName')
let price = document.getElementById('price')
let ItemName = document.getElementById('ItemName')
let category = document.getElementById('category')
let delivery = document.getElementById('delivery')
let randomId = Math.floor(Math.random() * 124903)
console.log(randomId)
async function Addproduct(){
  let id = randomId
  let url = await uploadImage(id)
  console.log(url)
  getProducts(id)
  await db.collection("products").doc().set({
    restaurantName : restaurantName.value,
    price : price.value,
    ItemName : ItemName.value,
    category : category.value,
    delivery : delivery.value,
    Id : randomId,
    image : url
})
.then(() => {
    console.log("Document successfully written!");
    restaurantName.value = '';
    price.value = '';
    ItemName.value = '';
})
.catch((error) => {
    console.error("Error writing document: ", error);
});
}

function uploadImage(id){
  return new Promise(async (resolve,reject) => {
let file = document.getElementById('file')
let image = file.files[0]
let storageRef = storage.ref()
let imageRef = storageRef.child(`productimage/${id}/${image.name}`);
await imageRef.put(image)
let url = await imageRef.getDownloadURL();
resolve(url)
})}

function getProducts(){
  db.collection("products").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        console.log(doc.id, " => ", doc.data());
    // let container = document.createElement('div')
    // container.setAttribute('class','container')
    // let row = document.createElement('div')
    // row.setAttribute('class','row')
    // let col = document.createElement('div')
    // col.setAttribute('class','col-md-4')
    // let img = document.createElement("img")
    // img.setAttribute('src',doc.data().image)
    // img.setAttribute('class','card-img-top')
    // img.setAttribute('id','cardimg')
    // card.appendChild(img);
    // let div = document.createElement('div')
    // div.setAttribute('class','card-body')
    // let h5 = document.createElement("h5")
    // let h5Text = document.createTextNode('Category: ' + doc.data().ItemName)
    // h5.appendChild(h5Text);
    // h5.setAttribute('class','card-title')
    // h5.setAttribute('id','title')
    // card.appendChild(h5);
    // let resh4 = document.createElement("h4")
    // let resText = document.createTextNode('Restaurant Name: ' + doc.data().restaurantName)
    // resh4.appendChild(resText)
    // card.appendChild(resh4)
    // let ordMSG = document.createElement("p")
    // let ordText = document.createTextNode('   ')
    // ordMSG.appendChild(ordText)
    // ordMSG.style.color = 'green';
    // ordMSG.setAttribute('id','ordMSG')
    // card.appendChild(ordMSG)
    // let p = document.createElement("p")
    // let pText = document.createTextNode('Some quick example text to build on the card title and make up the bulk of the cards content.')
    // p.appendChild(pText)
    // p.setAttribute('class','card-text')
    // card.appendChild(p)
    // let price = document.createElement("p")
    // let priText = document.createTextNode('Rs: ' + doc.data().price)
    // price.appendChild(priText)
    // price.setAttribute('id','Price')
    // card.appendChild(price)
    // let btn = document.createElement('button')
    // let btnText = document.createTextNode('Order')
    // btn.appendChild(btnText)
    // btn.setAttribute('class','orderBTN')
    // btn.setAttribute('onclick','orderFunc(this)')
    // card.appendChild(btn)
    // cards.appendChild(card)
    // div.appendChild.card
    // col.appendChild(div)
    // row.appendChild(col)
    // container.appendChild(row)
    const mainCardDetail = `
     <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="main-card">
         <img src="${doc.data().image}" alt="res-img"/> 
         <h5 class="card-title" id="title">Category: ${doc.data().ItemName}</h5>
         <h4 class="card-title" id="title">Restaurant: ${doc.data().restaurantName}</h4>
         <p style="color: green;" id="ordMsg"></p>
         <p class="card-text">Some quick example text to build on the card title and make up the bulk of the cards content.</p>
         <p id="Price">Rs : ${doc.data().price}</p>
         <button class="orderBtn onclick="orderFunc(this)">Order</button>
         </div> 
       <div>
     </div>
     </div>
    `
    cards.innerHTML += mainCardDetail
  
    });
});
}
getProducts();

async function orderFunc(){
  let ordMsg = card.childNodes[11]
  ordMsg.innerText = 'Order Placed...Thanks You'
}


async function register(){
   await firebase.auth().createUserWithEmailAndPassword(emailEl.value, passwordEl.value)
  .then(async(userCredential) => {
    // Signed in 
    var user = userCredential.user;
    let uid = user.uid
    console.log(user)
    errorMsg.innerText = 'Register Successfully'
    errorMsg.style.color='green'
    let obj = {
        username : userName.value,
        email : emailEl.value,
        password : passwordEl.value,
        uid : uid,
        phone : usernumber.value,
        country : usercountry.value,
        role : userRole.selected  
    }
    console.log(obj)
   await db.collection('users').doc(uid).set(obj)
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
    errorMsg.innerText = errorMessage
    // ..
  });
}
let role;
function loginForm(){
  firebase.auth().signInWithEmailAndPassword(emailEl.value, passwordEl.value)
   .then((userCredential) => {
     // Signed in
     var user = userCredential.user;
     console.log(user , '49')
     uid = user.uid
     let docRef = db.collection('users').doc(uid);
      docRef.get().then((doc) => {
        if (doc.exists) {
            let role = doc.data().role
            console.log("Document data:", doc.data(),role);
          if(role === true){
            window.location = 'restaurant.html'
          }
          else{
            window.location = 'home.html'
          }
          }})
    //  window.location = 'home.html'
     // ...
  })
   .catch((error) => {
     var errorCode = error.code;
     var errorMessage = error.message;
     errorMsg.innerText = errorMessage
   });
 
 }



let userEl = document.getElementById('user')
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      var uid = user.uid;
      console.log(user)
      console.log(uid)
      let docRef = db.collection('users').doc(uid);
      docRef.get().then((doc) => {
        if (doc.exists) {
            console.log("Document data:", doc.data());
            let usernameEl = doc.data().username;
            userEl.innerText = usernameEl
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
    
      
}})

function signout(){
    firebase.auth().signOut().then(() => {
        console.log('SignOut')
        window.location = 'login.html'
        // Sign-out successful.
      }).catch((error) => {
        errorMsg.innerText = error.message
      });
      
}
  

